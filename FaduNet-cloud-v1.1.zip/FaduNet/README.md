# FaduNet 1.1 — versión para compilación en la nube

Proyecto Java liviano con WebView, interfaz lila/azul y bloqueo básico de dominios publicitarios.

Esta edición actualiza las herramientas de compilación porque la versión antigua 2.3.3 del proyecto original ya no se puede descargar desde los repositorios que tiene disponibles el flujo en la nube.

## Herramientas de compilación

- Android Gradle Plugin 4.2.2
- Gradle 6.7.1
- Java 11 para Gradle
- Android SDK 30 y Build Tools 30.0.3
- SDK mínimo 16

El workflow de GitHub Actions debe preparar Java 17 antes de instalar el SDK, Java 11 antes de Gradle y ejecutar `assembleDebug`. El APK de prueba queda en `app/build/outputs/apk/debug/app-debug.apk`.
