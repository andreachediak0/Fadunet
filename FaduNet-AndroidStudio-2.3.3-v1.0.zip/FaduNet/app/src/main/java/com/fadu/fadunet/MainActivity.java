package com.fadu.fadunet;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://start.fadunet.local/";
    private static final int INK = Color.rgb(43, 39, 74);
    private static final int PURPLE = Color.rgb(126, 91, 239);
    private static final int BLUE = Color.rgb(61, 139, 246);
    private static final int PALE = Color.rgb(244, 241, 255);

    private static final Set<String> AD_HOSTS = new HashSet<String>(Arrays.asList(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "adnxs.com", "adform.net", "adroll.com",
            "adsrvr.org", "advertising.com", "bidswitch.net", "casalemedia.com",
            "contextweb.com", "criteo.com", "criteo.net", "openx.net",
            "outbrain.com", "pubmatic.com", "revcontent.com", "rubiconproject.com",
            "scorecardresearch.com", "sharethrough.com", "smartadserver.com",
            "taboola.com", " lijit.com", "yieldmo.com", "zedo.com"
    ));

    private EditText addressBar;
    private TextView blockerStatus;
    private Button blockerButton;
    private ProgressBar progressBar;
    private WebView webView;
    private boolean blockerEnabled = true;

    private static final String HOME_HTML = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><meta charset='utf-8'><style>" +
            "*{box-sizing:border-box}body{margin:0;padding:26px 20px;font-family:Arial,sans-serif;color:#2b274a;background:linear-gradient(145deg,#f5f0ff,#eaf4ff);min-height:100vh}" +
            ".mark{width:62px;height:62px;border-radius:22px;background:linear-gradient(135deg,#8b5cf6,#3989f5);color:white;font-weight:bold;font-size:28px;display:flex;align-items:center;justify-content:center;box-shadow:0 8px 20px #9583d555}" +
            "h1{font-size:28px;margin:18px 0 4px}p{color:#706c89;margin:0 0 22px}.box{background:white;border-radius:18px;padding:18px;box-shadow:0 8px 24px #71679a22}" +
            "input{width:100%;padding:14px;border:1px solid #ddd8f0;border-radius:12px;font-size:16px;outline:none}button{width:100%;margin-top:10px;padding:13px;border:0;border-radius:12px;background:linear-gradient(90deg,#8b5cf6,#3989f5);color:white;font-size:16px;font-weight:bold}" +
            ".label{margin:25px 0 11px;font-size:13px;font-weight:bold;color:#77718d}.links{display:flex;flex-wrap:wrap;gap:9px}a{display:inline-block;text-decoration:none;color:#514989;background:#fff;padding:12px 14px;border-radius:13px;font-size:14px;box-shadow:0 4px 14px #71679a18}" +
            ".note{font-size:12px;margin-top:28px;color:#88839b}</style></head><body><div class='mark'>F</div><h1>Hola, estás en FaduNet</h1><p>Una forma liviana de navegar.</p>" +
            "<div class='box'><form action='https://www.google.com/search' method='get'><input name='q' type='search' placeholder='¿Qué querés buscar?' autofocus><button type='submit'>Buscar en internet</button></form></div>" +
            "<div class='label'>ACCESOS RÁPIDOS</div><div class='links'><a href='https://www.wikipedia.org/'>Wikipedia</a><a href='https://www.youtube.com/'>YouTube</a><a href='https://www.openstreetmap.org/'>Mapas</a></div>" +
            "<div class='note'>El bloqueador de anuncios está activado. Algunos anuncios pueden aparecer si el sitio los sirve desde su propio dominio.</div></body></html>";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.rgb(91, 69, 190));
            getWindow().setNavigationBarColor(Color.rgb(55, 83, 173));
        }
        buildScreen();
        configureBrowser();
        showHome();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18), dp(13), dp(18), dp(13));
        header.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(133, 91, 238), Color.rgb(57, 133, 239)}));
        TextView brand = new TextView(this);
        brand.setText("FaduNet");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(22);
        brand.setTypeface(null, 1);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView tagline = new TextView(this);
        tagline.setText("LIVIANO · PRIVADO");
        tagline.setTextColor(Color.rgb(238, 235, 255));
        tagline.setTextSize(10);
        if (Build.VERSION.SDK_INT >= 21) tagline.setLetterSpacing(0.08f);
        header.addView(tagline);
        root.addView(header);

        LinearLayout addressRow = new LinearLayout(this);
        addressRow.setGravity(Gravity.CENTER_VERTICAL);
        addressRow.setPadding(dp(12), dp(10), dp(12), dp(5));
        addressRow.setBackgroundColor(Color.WHITE);
        addressBar = new EditText(this);
        addressBar.setSingleLine(true);
        addressBar.setTextSize(15);
        addressBar.setHint("Buscar o escribir dirección web");
        addressBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        addressBar.setPadding(dp(14), 0, dp(10), 0);
        addressBar.setBackground(roundRect(Color.rgb(246, 244, 252), Color.rgb(232, 228, 246), dp(13)));
        addressRow.addView(addressBar, new LinearLayout.LayoutParams(0, dp(46), 1));
        Button go = makeButton("Ir", PURPLE, Color.WHITE);
        LinearLayout.LayoutParams goParams = new LinearLayout.LayoutParams(dp(54), dp(44));
        goParams.leftMargin = dp(8);
        addressRow.addView(go, goParams);
        root.addView(addressRow);

        LinearLayout controls = new LinearLayout(this);
        controls.setPadding(dp(9), dp(3), dp(9), dp(7));
        controls.setGravity(Gravity.CENTER);
        Button back = makeButton("Atrás", PALE, INK);
        Button home = makeButton("Inicio", PALE, INK);
        Button reload = makeButton("Recargar", PALE, INK);
        blockerButton = makeButton("Bloqueo ON", Color.rgb(232, 247, 242), Color.rgb(27, 133, 103));
        addWeighted(controls, back);
        addWeighted(controls, home);
        addWeighted(controls, reload);
        addWeighted(controls, blockerButton);
        root.addView(controls);

        FrameLayout browserFrame = new FrameLayout(this);
        webView = new WebView(this);
        browserFrame.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        if (Build.VERSION.SDK_INT >= 21) progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(PURPLE));
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP);
        browserFrame.addView(progressBar, progressParams);
        root.addView(browserFrame, new LinearLayout.LayoutParams(-1, 0, 1));

        blockerStatus = new TextView(this);
        blockerStatus.setTextColor(Color.rgb(86, 77, 134));
        blockerStatus.setTextSize(11);
        blockerStatus.setGravity(Gravity.CENTER);
        blockerStatus.setPadding(dp(8), dp(7), dp(8), dp(7));
        blockerStatus.setBackgroundColor(Color.rgb(247, 245, 253));
        root.addView(blockerStatus);
        setContentView(root);
        refreshBlockerLabel();

        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { navigateFromBar(); }
        });
        addressBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    navigateFromBar();
                    return true;
                }
                return false;
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (webView.canGoBack()) webView.goBack(); }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showHome(); }
        });
        reload.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (webView.getUrl() == null || HOME_URL.equals(webView.getUrl())) showHome(); else webView.reload(); }
        });
        blockerButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                blockerEnabled = !blockerEnabled;
                refreshBlockerLabel();
                if (webView.getUrl() != null && !HOME_URL.equals(webView.getUrl())) webView.reload();
                Toast.makeText(MainActivity.this, blockerEnabled ? "Bloqueador activado" : "Bloqueador desactivado", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void configureBrowser() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setAllowFileAccess(false);
        if (Build.VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return true;
                Uri uri = Uri.parse(url);
                String scheme = uri.getScheme();
                if (scheme != null && ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))) return false;
                if (scheme != null && ("mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                }
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                if (blockerEnabled && isAdUrl(url)) {
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (url != null && !HOME_URL.equals(url)) addressBar.setText(url);
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (HOME_URL.equals(url)) addressBar.setText("");
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
            }

        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });
    }

    private void navigateFromBar() {
        String value = addressBar.getText().toString().trim();
        if (value.length() == 0) return;
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(addressBar.getWindowToken(), 0);
        String target;
        String lower = value.toLowerCase(Locale.US);
        if (lower.startsWith("http://") || lower.startsWith("https://")) {
            target = value;
        } else if (!containsWhitespace(value) && (android.util.Patterns.WEB_URL.matcher(value).matches() || value.startsWith("www."))) {
            target = "https://" + value;
        } else {
            try { target = "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8"); }
            catch (Exception e) { target = "https://www.google.com/"; }
        }
        webView.loadUrl(target);
    }

    private boolean containsWhitespace(String value) {
        for (int i = 0; i < value.length(); i++) if (Character.isWhitespace(value.charAt(i))) return true;
        return false;
    }

    private boolean isAdUrl(String url) {
        try {
            String host = Uri.parse(url).getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.US);
            if (host.endsWith(".")) host = host.substring(0, host.length() - 1);
            for (String domain : AD_HOSTS) {
                String cleanDomain = domain.trim();
                if (host.equals(cleanDomain) || host.endsWith("." + cleanDomain)) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    private void showHome() {
        webView.loadDataWithBaseURL(HOME_URL, HOME_HTML, "text/html", "UTF-8", null);
        addressBar.setText("");
    }

    private void refreshBlockerLabel() {
        blockerButton.setText(blockerEnabled ? "Bloqueo ON" : "Bloqueo OFF");
        blockerButton.setTextColor(blockerEnabled ? Color.rgb(27, 133, 103) : Color.rgb(115, 103, 131));
        blockerButton.setBackground(roundRect(blockerEnabled ? Color.rgb(232, 247, 242) : PALE, Color.TRANSPARENT, dp(12)));
        blockerStatus.setText(blockerEnabled ? "✓ Bloqueador de anuncios activado" : "Bloqueador de anuncios desactivado");
    }

    private Button makeButton(String text, int bg, int fg) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(11);
        button.setTextColor(fg);
        button.setAllCaps(false);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(5), 0, dp(5), 0);
        button.setBackground(roundRect(bg, Color.TRANSPARENT, dp(12)));
        return button;
    }

    private void addWeighted(LinearLayout row, Button button) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(40), 1);
        params.leftMargin = dp(3);
        params.rightMargin = dp(3);
        row.addView(button, params);
    }

    private GradientDrawable roundRect(int color, int strokeColor, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (strokeColor != Color.TRANSPARENT) drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else if (webView != null && !HOME_URL.equals(webView.getUrl())) showHome();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
        }
        super.onDestroy();
    }
}
